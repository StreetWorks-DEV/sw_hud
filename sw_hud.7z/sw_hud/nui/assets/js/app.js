
$(document).ready(() => {
	Vue.use(Toasted, {
        iconPack: 'fontawesome'
    })

	const app = new Vue({
		el: "#app",

		data: {
			time: 0,
      id: 0,

      talking: false,

      zapas: []
		},
	})

  const el = document.getElementById('hud');
  window.addEventListener('message', (event) => {
        let data = event.data
  if(data.armor < 1) {
      document.getElementById('armor').style.display = "none"
    } else if(data.armor == undefined) {

  } else {

      document.getElementById('armor').style.display = "block"
    }
    if(data.health > 99) {
      document.getElementById('health').style.display = "none"
    } else if(data.health == undefined) {

} else {

      document.getElementById('health').style.display = "block"
    }

    if(data.lungh > 99) {
      document.getElementById('lungh').style.display = "none"
    } else if(data.health == undefined) {

} else {

      document.getElementById('lungh').style.display = "block"
    }
    if(data.display == true) {
      setTimeout(() => {
        el.style.visibility = 'visible';
      }, 100); 
    }else if(data.display == false) {
      setTimeout(() => {
        el.style.visibility = 'hidden';
      }, 100); 
    }
  })
  
  const hudElements = {
    health: {
      color: '#3F92FF',
      bg_color: 'rgba(22, 25, 35, 0.767)',
      blinking: true,
    },

    armor: {
      color: '#3F92FF',
      bg_color: 'rgba(22, 25, 35, 0.767)',
      blinking: true,
    },

    hunger: {
      color: '#3F92FF',
      bg_color: 'rgba(22, 25, 35, 0.767)',
      blinking: true,
    },

    thirst: {
      color: '#3F92FF',
      bg_color: 'rgba(22, 25, 35, 0.767)',
      blinking: true,
    },

    stamina: {
      color: '#3F92FF',
      bg_color: 'rgba(22, 25, 35, 0.767)',
      blinking: true,
    },
    lungh: {
      color: '#3F92FF',
      bg_color: 'rgba(22, 25, 35, 0.767)',
      blinking: true,
    },
  };

  const Root = document.querySelector('.hud');

  Object.entries(hudElements).forEach((elem) => {
    const [name, value] = elem;

    $('#' + name).circleProgress({
      value: 1,
      size: 270,
      thickness: 24,
      animation: false,
      fill: value.color,
      startAngle: -Math.PI / 2,
      emptyFill: value.bg_color || 'rgba(22, 25, 35, 0.767)',
    });
  });

  let notificationId = 0;
  let movedNotifs = 0;
  function ShowStatusNotification(text, icon, color) {
    notificationId++;
    let notificationCounter = notificationId;
    $("#notifications").append(`
      <div class="notification" id="notification-${notificationCounter}">
          <div class="notification-block">
              <div class="notification-block-icon">
                  <i style="color: ${color}" class="fas fa-${icon}"></i>
              </div>
              <div class="notification-block-text">
                  <div class="text">${text}</div>
              </div>
          </div>
      </div>
    `)

    setTimeout(function (){
      $(`#notification-${notificationCounter}`).css("animation-name", "fadeIn");
      movedNotifs++;
      $(`#notification-${notificationCounter}`).css("height", $(`#notification-${notificationCounter}`).height());
    }, 1000 + 3000);
    setTimeout(function (){
      $(`#notification-${notificationCounter}`).css("height", "0");
      $(`#notification-${notificationCounter}`).css("margin-top", "0");
    }, 1000 + 3000 + 1000);
    setTimeout(function (){
      $(`#notification-${notificationCounter}`).remove();
    }, 1000 + 3000 + 1000 + 300)
  }

  window.addEventListener('message', function(event) {
      var data = event.data

      if (data.mugshot != undefined) {
        const elem = Root.querySelector('.mugshot');
        app.mugshot = data.mugshot

        return;
      }

      switch (data.type) {
        case 'notification':
          ShowStatusNotification(data.text, data.icon, data.color)
          break;
        case 'talking':
          app.talking = data.talking
          break;
        case 'identifier':
          app.id = data.id
          break;
        case 'time':
          app.time = data.time
          break;
      }

      Object.entries(data).forEach((elem) => {
          const [name, value] = elem;
      
          if (hudElements[name]) {
            $('#' + name).circleProgress({
              value: value / 100,
            });
          }
      });
  })
})