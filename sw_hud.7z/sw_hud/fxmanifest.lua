fx_version 'bodacious'
game 'gta5'
lua54 'yes'

author 'StreetWorks'
version '1.0.0'

client_scripts {
    'client/*.lua',
    'client/*.js'
}


ui_page 'nui/index.html'

files {
    'nui/index.html',
    'nui/assets/css/**.css',
    'nui/assets/js/**.js',
    'nui/assets/img/**.png',
}



dependency '/assetpacks'