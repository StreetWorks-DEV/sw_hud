let mug = false;

function modelLoadedAsync() {
  return new Promise((resolve) => {
    const timer = setInterval(() => {
      const ped = PlayerPedId();
      const model = GetEntityModel(ped);

      if (model && HasModelLoaded(model)) {
        resolve(ped);
        clearInterval(timer);
      }
    }, 100);
  });
}

function ShowNotification(text, icon, color) {
  SendNUIMessage({
    type: 'notification',
    text: text,
    icon: icon,
    color: color
  });
}

async function getMugshot() {
  const ped = await modelLoadedAsync();

  mug = RegisterPedheadshotTransparent(ped);

  const timer = setInterval(() => {
    if (!IsPedheadshotValid(mug)) {
      UnregisterPedheadshot(mug);

      mug = RegisterPedheadshotTransparent(ped);
    } else {
      if (IsPedheadshotReady(mug)) {
        SendNUIMessage({
          mugshot: GetPedheadshotTxdString(mug),
        });
        UnregisterPedheadshot(mug);
        clearInterval(timer);
      }
    }
  }, 100);
}



function resourceStart() {
  SendNUIMessage({
    type: 'identifier',
    id: GetPlayerServerId(PlayerId()),
  });

  getMugshot();
}

setTimeout(resourceStart, 2000);

onNet('playerSpawned', () => {
  setTimeout(resourceStart, 2000);
});

on('onClientResourceStop', (resourceName) => {
  if (GetCurrentResourceName() != resourceName) {
    return;
  }
  if (mug) UnregisterPedheadshot(mug);
});

setInterval(async () => {
  const ped = PlayerPedId();
  const playerId = PlayerId();

  SendNUIMessage({
    health: GetEntityHealth(ped) - (GetEntityMaxHealth(ped) === 175 ? 75 : 100),
    armor: GetPedArmour(ped),
    stamina: 100 - GetPlayerSprintStaminaRemaining(playerId),
    lungh: GetPlayerUnderwaterTimeRemaining(PlayerId()) * 10, 
  });

  if (NetworkIsPlayerTalking(playerId)) {
    SendNUIMessage({
      type: 'talking',
      talking: true
    });
  } else if(!NetworkIsPlayerTalking(playerId)) {
    SendNUIMessage({
      type: 'talking',
      talking: false
    });
  }

  SendNUIMessage({
    type: 'time',
    time: GetClockHours() + ':' + GetClockMinutes(),
  });
}, 100);

setInterval(async () => {
  const hunger = await getStatus('hunger');
  const thirst = await getStatus('thirst');

  if (hunger < 10) {
    ShowNotification('Twój poziom głodu znacznie się zmniejsza, zjedz coś', 'hamburger', '#da800a')
  } else if(thirst < 10) {
    ShowNotification('Twój poziom głodu znacznie się zmniejsza, zjedz coś', 'whiskey-glass', '#12e4f3')
  }

  SendNUIMessage({
    hunger,
    thirst,
  });
}, 1000);

function getStatus(name = 'hunger') {
  return new Promise((resolve) => {
    emit('esx_status:getStatus', name, (status) => {
      resolve(status.getPercent());
    });
  });
}
